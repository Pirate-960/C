#ifndef HEADER_FILE //include guards prevent multiple includsion
#define HEADER_FILE //if not yet defined, define it
//optional but recommended

int square (int input);
int cube(int input);
int power(int input, int exponent);
int recursivePower(int input, int exponent);
void changeVal(int *a);
int oldestValue( int *ages, int size);

#endif
